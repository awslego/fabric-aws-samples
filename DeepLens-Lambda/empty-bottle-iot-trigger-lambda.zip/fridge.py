import os.path

# file name for storing count
file_name = "check_count.log"
thresh_hold = 5


def is_empty():

    result = False

    is_file_exist = os.path.isfile(file_name)

    if not is_file_exist:
        log_file = open(file_name, "w")
        log_file.close()

    log_file = open(file_name, "r+")
    accumulated_count = log_file.readline()

    if accumulated_count == "":
        accumulated_count = 1
    else:
        accumulated_count = int(accumulated_count) + 1

    print(accumulated_count)

    if accumulated_count >= thresh_hold:
        result = True
        accumulated_count = 0


    log_file.seek(0)
    log_file.write(str(accumulated_count))
    log_file.truncate()
    log_file.close()

    return result



