import handleOrder
import json

def lambda_handler(event, context):
    #jsonString = '{"bottle": 3}'
    # jsonString = event
    # jsonObject = json.loads(jsonString)
    jsonObject = event
    print(event)

    if 'bottle' not in jsonObject:
        result = handleOrder.order_beer()
        print(result)
    else:
        print('Fridge is not empty')