# coding=utf-8
import json
import requests

API_HOST = 'http://beer-supplychain-alb-2109300575.ap-northeast-2.elb.amazonaws.com'
headers = {'X-username': 'client1', 'X-orgName': 'Org1'}


def order_beer():
    response = _req("/orders/ORDER0", "", "GET", "")

    if response.status_code == 200:
        if response.text != "":
            jsonObject = json.loads(response.text)
            owner = jsonObject['owner']
            if owner == 'Retailer':
                print("No previous Order is in process. Going to order right now.")

                data = {"Key": "ORDER0", "State": "0", "Owner": "Manufacturer", "Count": "10"}
                response = _req("/orders", "", "POST", data)

                if response.status_code == 200:
                    print("New order process just started.")
                    return True
                else:
                    print("New order process failed.")
                    return False

            else:
                print("Previous Order is in process. Don't order right now.")
                return False
        else:
            print("response is empty")
            return False

    else:
        print("error occurred.")
        return False


def _req(path, query, method, data={}):
    url = API_HOST + path
    print('HTTP Method: %s' % method)
    print('Request URL: %s' % url)
    print('Headers: %s' % headers)
    print('QueryString: %s' % query)

    if method == 'GET':
        return requests.get(url, headers=headers)
    else:
        return requests.post(url, headers=headers, data=data)
